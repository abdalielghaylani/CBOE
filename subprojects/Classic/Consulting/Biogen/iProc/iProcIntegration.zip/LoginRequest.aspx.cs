using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//
using Util;
using System.IO;
using System.Diagnostics;
using System.Text;
using System.Xml;
using System.Net;
//
public partial class LoginRequest : System.Web.UI.Page
{
    /// <summary>
    /// 
    /// </summary>
    private XMLUtil xmlUtil = new XMLUtil();

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        int OracleCart = 0;

        if (this.Request.Params["oracleCart"] != null)
        {
                Response.Write(Server.HtmlEncode(Request.Params["oracleCart"].ToString()));
                OracleCart = 1;
        }

       if ((!this.IsPostBack) && OracleCart==0)
           {
                //
                Stream resStream = Request.InputStream;
                byte[] buf = new byte[8192];
                StringBuilder sb = new StringBuilder();
                //
                if (resStream != null)
                {
                    string tempString = null;
                    int count = 0;

                    do
                    {
                        // fill the buffer with data
                        count = resStream.Read(buf, 0, buf.Length);

                        // make sure we read some data
                        if (count != 0)
                        {
                            // translate from bytes to ASCII text
                            tempString = Encoding.ASCII.GetString(buf, 0, count);

                            // continue building the string
                            sb.Append(tempString);
                        }
                    }
                    while (count > 0); // any more data to read?

                    // print out page source
                    if (sb.Length > 1)
                    {
                        //shopcart reading ....... if exists

                        this.BindURLDataFromLoginResponse(sb.ToString());

                        //                
                    }
                    else
                    {
                        //do nothing.......there's no response
                        this.SetDefaultsGUI();
                    }
                }


            }
    }
  

    private void SetDefaultsGUI()
    {
        this.panelURLResponse.Visible = false;
        
        this.lbtnLoginRequest.Visible = true;
    }

    protected void lbtnLoginRequest_Click(object sender, EventArgs e)
    {
        byte[] buf = new byte[8192];
        HttpWebRequest req = null;
        HttpWebResponse rsp = null;
        StringBuilder sb = new StringBuilder();
        //
        try
        {
            string fileName = System.Configuration.ConfigurationManager.AppSettings["xmlDir"].ToString() + "LoginRequest.xml";
            string uri = System.Configuration.ConfigurationManager.AppSettings["targetURL"].ToString() + "LoginRequestHandler.aspx";                   
           
            req = (HttpWebRequest) WebRequest.Create(uri);            
            // Post method
            req.Method = "POST";
            // content type
            req.ContentType = "application/x-www-form-urlencoded";            
            // Wrap the request stream with a text-based writer
            //StreamWriter writer = new StreamWriter(req.GetRequestStream()); 

            string RequestString = "loginRequest=" + Server.UrlEncode(this.xmlUtil.GetTextFromXMLFile(fileName));
            Response.Write("<Br>" + RequestString.Length + "-------<BR>");
            
            byte[] buffer = Encoding.ASCII.GetBytes(RequestString);
            req.ContentLength = buffer.Length;
            Response.Write("*" + buffer.Length + "*");
            Stream writer = req.GetRequestStream();
            // Write the XML text into the stream

            writer.Write(buffer, 0, buffer.Length);
            writer.Close();
            // Send the data to the webserver
            rsp = (HttpWebResponse) req.GetResponse();
            Response.Write("<BR>*" + rsp.ResponseUri + " <BR>");
            Response.Write("**" + rsp.StatusCode + "---");
        }
        catch (WebException webEx)
        {
            Response.Write(webEx.ToString());
            Response.End();
        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
            Response.End();
        }
        finally
        {
            if (req != null) req.GetRequestStream().Close();
            //
            if (rsp != null)
            {

                Stream resStream = rsp.GetResponseStream();
                string tempString = null;
                int count = 0;

                do
                {
                    // fill the buffer with data
                    count = resStream.Read(buf, 0, buf.Length);

                    // make sure we read some data
                    if (count != 0)
                    {
                        // translate from bytes to ASCII text
                        tempString = Encoding.ASCII.GetString(buf, 0, count);

                        // continue building the string
                        sb.Append(tempString);
                    }
                }
                while (count > 0); // any more data to read?
                //
                //print out page source
                Response.Write("Received Response-");
                Response.Write("<br>" + Server.HtmlEncode(ReadLoginURLFromResponse(sb.ToString())) + "<BR>");
                Response.Write("<br><a href='" + ReadLoginURLFromResponse(sb.ToString()) + "'>Punch out</a><BR>");
                Response.Write("<br>" + Server.HtmlEncode(sb.ToString()) + "<BR>");
                Response.Write("-End");
                Response.End();
            }
        }        
    }

    private void BindDataFromShoppingCartXML(string xml)
    {        
        string oracleCart = Request["oracleCart"].ToString();
        
        this.panelURLResponse.Visible = false;

    }

    private void BindURLDataFromLoginResponse(string xml)
    {        
        //
        this.lbtnLoginRequest.Visible = false;
        string url = this.ReadLoginURLFromResponse(xml);
        this.lbtnResponseURL.Text = "<a href='" + url.Replace("\n", "").Replace("\r\n", "").Replace("\r\n", "") + "'>Go to Shopping Cart</a>";
        this.panelURLResponse.Visible = true;
    }

    private string ReadLoginURLFromResponse(String XMLResponse)
    {
        try
        {
            string tempStr;
            StringBuilder sb = new StringBuilder();
            StringReader stream = new StringReader(XMLResponse.Replace("&","&amp;").Replace("&amp;amp;","&amp;"));
            XmlTextReader reader = new XmlTextReader(stream);
            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element)
                {
                    Response.Write(reader.Name + "<BR>");
                    if (reader.Name == "loginURL")
                    {
                        tempStr = reader.ReadString();
                        Response.Write("*" + Server.HtmlEncode(tempStr) + "*");
                        return tempStr;
                    }
                }
            }
        }
        catch (Exception ex)
        {
        //
        }

        //
        return "";
    }
}
